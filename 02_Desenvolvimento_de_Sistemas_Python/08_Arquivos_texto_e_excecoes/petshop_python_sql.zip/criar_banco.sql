CREATE DATABASE petshop;
GO

USE petshop;
GO

CREATE TABLE petshop (
    id INT PRIMARY KEY IDENTITY(1,1),
    tipo_pet VARCHAR(50) NOT NULL,
    nome_pet VARCHAR(50) NOT NULL,
    idade INT NOT NULL
);
GO
