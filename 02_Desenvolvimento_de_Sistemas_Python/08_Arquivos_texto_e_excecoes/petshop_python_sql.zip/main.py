import pyodbc
import subalgs as sub

# conexao
try:
    conn = sub.conectar()
except pyodbc.Error as erro:
    print("Erro ao conectar:", erro)
else:
    escolha = ""

    # menu principal
    while escolha != "0":
        sub.limpar_tela()
        sub.menu_principal()
        escolha = input("Escolha: ").strip()

        match escolha:
            case "1":
                sub.cadastrar_pet(conn)
            case "2":
                sub.listar_pets(conn)
            case "3":
                sub.editar_pet(conn)
            case "4":
                sub.excluir_pet(conn)
            case "5":
                sub.excluir_todos(conn)
            case "6":
                sub.menu_filtros(conn)
            case "0":
                print("Programa encerrado!")
            case _:
                print("Opcao invalida!")

        if escolha != "0":
            sub.pausar()

    conn.close()
