import os
import pyodbc
import pandas as pd


# --------- funcoes

def montar_conexao(server: str, database: str, username: str, password: str, driver: str) -> str:
    return (
        f"DRIVER={driver};SERVER={server};DATABASE={database};"
        f"UID={username};PWD={password}"
    )


def nome_valido(nome: str) -> bool:
    return nome.strip() != ""


def idade_valida(idade: int) -> bool:
    return idade >= 0 and idade <= 120


def montar_filtro(tipo: str, texto: str) -> str:
    match tipo:
        case "1":
            return texto
        case "2":
            return texto + "%"
        case "3":
            return "%" + texto
        case "4":
            return "%" + texto + "%"
        case _:
            return ""


def consulta_nome(conn: pyodbc.Connection, tipo: str, texto: str) -> list:
    cursor = conn.cursor()
    filtro = montar_filtro(tipo, texto)
    cursor.execute(
        "SELECT id, tipo_pet, nome_pet, idade FROM petshop "
        "WHERE nome_pet LIKE ? ORDER BY id",
        filtro
    )
    dados = cursor.fetchall()
    cursor.close()
    return dados


def buscar_pet(conn: pyodbc.Connection, id_pet: int) -> list:
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, tipo_pet, nome_pet, idade FROM petshop WHERE id = ?",
        id_pet
    )
    dados = cursor.fetchall()
    cursor.close()
    return dados


def todos_pets(conn: pyodbc.Connection) -> list:
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, tipo_pet, nome_pet, idade FROM petshop ORDER BY id"
    )
    dados = cursor.fetchall()
    cursor.close()
    return dados


# --------- procedimentos

def conectar() -> pyodbc.Connection:
    server = "localhost"
    database = "petshop"
    username = "sa"
    password = "SUA_SENHA"
    driver = "{ODBC Driver 17 for SQL Server}"
    texto = montar_conexao(server, database, username, password, driver)
    return pyodbc.connect(texto)


def limpar_tela():
    os.system("cls" if os.name == "nt" else "clear")


def pausar():
    input("\\nPressione ENTER para continuar...")


def menu_principal():
    print("""
========= PETSHOP =========
0 - SAIR
1 - CADASTRAR PET
2 - LISTAR PETS
3 - EDITAR PET
4 - EXCLUIR PET
5 - EXCLUIR TODOS OS PETS
6 - FILTRAR POR NOME
""")


def mostrar_pets(dados: list):
    if len(dados) == 0:
        print("Nao ha pets para mostrar.")
    else:
        tabela = pd.DataFrame.from_records(
            dados,
            columns=["Id", "Tipo", "Nome", "Idade"]
        )
        print(tabela.to_string(index=False))


def cadastrar_pet(conn: pyodbc.Connection):
    print("------ CADASTRAR PET ------")
    tipo = input("Tipo do pet: ").strip()
    nome = input("Nome do pet: ").strip()

    try:
        idade = int(input("Idade do pet: "))
    except ValueError:
        print("Digite uma idade numerica!")
    else:
        if not nome_valido(tipo) or not nome_valido(nome):
            print("Tipo e nome nao podem ficar vazios!")
        elif not idade_valida(idade):
            print("A idade deve estar entre 0 e 120!")
        else:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO petshop (tipo_pet, nome_pet, idade) VALUES (?, ?, ?)",
                tipo, nome, idade
            )
            conn.commit()
            cursor.close()
            print("Pet cadastrado com sucesso!")


def listar_pets(conn: pyodbc.Connection):
    print("------ PETS CADASTRADOS ------")
    mostrar_pets(todos_pets(conn))


def editar_pet(conn: pyodbc.Connection):
    print("------ EDITAR PET ------")

    try:
        id_pet = int(input("ID do pet: "))
    except ValueError:
        print("Digite um ID numerico!")
    else:
        dados = buscar_pet(conn, id_pet)

        if len(dados) == 0:
            print("Pet nao encontrado!")
        else:
            mostrar_pets(dados)
            tipo = input("Novo tipo: ").strip()
            nome = input("Novo nome: ").strip()

            try:
                idade = int(input("Nova idade: "))
            except ValueError:
                print("Digite uma idade numerica!")
            else:
                if not nome_valido(tipo) or not nome_valido(nome):
                    print("Tipo e nome nao podem ficar vazios!")
                elif not idade_valida(idade):
                    print("A idade deve estar entre 0 e 120!")
                else:
                    cursor = conn.cursor()
                    cursor.execute(
                        "UPDATE petshop SET tipo_pet = ?, nome_pet = ?, idade = ? WHERE id = ?",
                        tipo, nome, idade, id_pet
                    )
                    conn.commit()
                    cursor.close()
                    print("Pet alterado com sucesso!")


def excluir_pet(conn: pyodbc.Connection):
    print("------ EXCLUIR PET ------")

    try:
        id_pet = int(input("ID do pet: "))
    except ValueError:
        print("Digite um ID numerico!")
    else:
        dados = buscar_pet(conn, id_pet)

        if len(dados) == 0:
            print("Pet nao encontrado!")
        else:
            mostrar_pets(dados)
            confirma = input("Deseja excluir este pet? (S/N): ").strip().upper()

            if confirma == "S":
                cursor = conn.cursor()
                cursor.execute("DELETE FROM petshop WHERE id = ?", id_pet)
                conn.commit()
                cursor.close()
                print("Pet excluido!")
            else:
                print("Exclusao cancelada!")


def excluir_todos(conn: pyodbc.Connection):
    confirma = input("Deseja excluir TODOS os pets? (S/N): ").strip().upper()

    if confirma == "S":
        cursor = conn.cursor()
        cursor.execute("DELETE FROM petshop")
        conn.commit()
        cursor.close()
        print("Todos os pets foram excluidos!")
    else:
        print("Exclusao cancelada!")


def menu_filtros(conn: pyodbc.Connection):
    escolha = ""

    while escolha != "0":
        limpar_tela()
        print("""
====== FILTRAR POR NOME ======
1 - Nome completo
2 - Comeca com
3 - Termina com
4 - Contem
0 - Voltar
""")
        escolha = input("Escolha: ").strip()

        match escolha:
            case "1" | "2" | "3" | "4":
                texto = input("Digite o nome ou trecho: ").strip()

                if nome_valido(texto):
                    dados = consulta_nome(conn, escolha, texto)
                    mostrar_pets(dados)
                else:
                    print("Digite um texto para pesquisar!")
            case "0":
                print("Voltando ao menu...")
            case _:
                print("Opcao invalida!")

        if escolha != "0":
            pausar()
